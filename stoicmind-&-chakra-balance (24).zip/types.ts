
export enum AppTab {
  INTRO = 'O Przewodniku',
  STOIC = 'Dzień Stoika',
  PHILOSOPHY = 'Filozofia Bytu',
  MEDITATE = 'Głęboka Medytacja',
  CHAKRAS = 'Harmonia Czakr',
  JOURNAL = 'Moje Zapiski',
  VOICE = 'Głos Wewnętrzny',
  CHAT = 'Dialog z Mędrcem',
  AFFIRMATIONS = 'Mantry i Pokój',
  ANALYSIS = 'Wieczorna Analiza',
  WATER = 'Źródło Życia',
  MILESTONES = 'Droga Wtajemniczenia',
  YOGA = 'Joga i Stawy',
  KNOWLEDGE_BASE = 'Baza Wiedzy AI',
  WATCH_MODE = 'Tryb Zegarka'
}

export interface UserProgress {
  points: number;
  level: number;
  completedTasks: string[];
}

export interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  category: 'Stoic' | 'Mantra' | 'Chakra' | 'Gratitude' | 'General' | 'Philosophy' | 'Health' | 'Wealth';
  tags: string[];
}

export interface StoicQuote {
  text: string;
  author: string;
}

export interface ChakraInfo {
  name: string;
  sanskrit: string;
  color: string;
  location: string;
  mantra: string;
  description: string;
}

export interface Mantra {
  text: string;
  translation: string;
  purpose: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
