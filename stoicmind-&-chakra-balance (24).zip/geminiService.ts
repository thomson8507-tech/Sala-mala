
import { GoogleGenAI } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getDailyStoicWisdom = async (mood?: string) => {
  const ai = getAI();
  const prompt = mood 
    ? `Jestem w nastroju: ${mood}. Podaj mi krótką poradę stoicką po polsku, która pomoże mi zachować spokój i racjonalność.`
    : "Podaj jedną krótką, inspirującą myśl stoicką na dziś w języku polskim.";
    
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Skup się na tym, co zależy od Ciebie.";
  }
};

/**
 * Wykorzystuje Google Search do odpowiedzi na trudne pytania filozoficzne,
 * działając jako "internetowa baza danych" wiedzy.
 */
export const getStoicInquiry = async (question: string) => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Jako ekspert od filozofii stoickiej i mądrości życiowej, odpowiedz na pytanie: "${question}". Skorzystaj z najnowszej wiedzy i pism mędrców. Odpowiedz po polsku.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    
    const text = response.text;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    return { text, sources };
  } catch (error) {
    console.error("Gemini Search Error:", error);
    return { text: "W tej chwili nie mogę połączyć się z kronikami wszechświata. Polegaj na swojej wewnętrznej mądrości.", sources: [] };
  }
};

export const startSageChat = (history: any[]) => {
  const ai = getAI();
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "Jesteś starożytnym mędrcem stoickim. Twoim zadaniem jest prowadzenie spokojnego, głębokiego dialogu z użytkownikiem. Odpowiadaj krótko, ale treściwie, używając metafor natury, ognia i lodu. Pomagaj odnaleźć wewnętrzny spokój. Twoje imię to Gwiezdny Mnich.",
    },
  });
};

export const generatePersonalizedMantra = async (focus: string) => {
  const ai = getAI();
  const prompt = `Stwórz krótką, rytmiczną mantrę (afirmację) po polsku skupioną na: ${focus}. Powinna brzmieć jak starożytne zaklęcie spokoju.`;
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Jestem spokojem i siłą.";
  }
};
