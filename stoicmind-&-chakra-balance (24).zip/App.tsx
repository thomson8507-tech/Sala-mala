
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { AppTab, Note, ChatMessage, ChakraInfo, UserProgress } from './types';
import { 
  CHAKRAS, MORNING_RITUAL, EVENING_RITUAL, 
  CHAKRA_PRACTICES, YOGA_PRACTICES, YOGA_SUBSCRIPTION, YogaExercise, PROGRESS_STEPS
} from './constants';
import { getDailyStoicWisdom, getStoicInquiry, startSageChat } from './geminiService';
import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";

// --- Pomocnicze funkcje Audio dla Live/TTS ---
function decode(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
  }
  return buffer;
}

// --- Komponent: Wirująca Geometria Czakry ---
const ChakraGeometry = React.memo(({ color, petals, size = "full" }: { color?: string, petals: number, size?: string }) => (
    <div className={`absolute inset-0 flex items-center justify-center opacity-40 group-hover:opacity-80 transition-opacity duration-500`}>
        <svg viewBox="0 0 100 100" className={`${size === "full" ? "w-full h-full" : "w-12 h-12"} animate-spin-slow group-hover:animate-spin-fast`}>
            {[...Array(petals)].map((_, i) => (
                <ellipse 
                    key={i} 
                    cx="50" cy="50" rx="45" ry="12" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="0.5" 
                    style={{ transform: `rotate(${(i * 360) / petals}deg)`, transformOrigin: '50% 50%' }}
                />
            ))}
            <circle cx="50" cy="50" r="15" fill="none" stroke="currentColor" strokeWidth="0.5" className="animate-pulse" />
        </svg>
    </div>
));

// --- Komponent: YogaBot V4 ---
const YogaBot = React.memo(({ activeMuscles, isBreathing, isContracting }: { activeMuscles: string[], isBreathing: boolean, isContracting?: boolean }) => (
    <div className="relative w-64 h-80 flex items-center justify-center perspective-1000">
        <div className={`absolute w-48 h-48 rounded-full border border-amber-500/10 transition-all duration-1000 ${isBreathing ? 'scale-125 opacity-30' : 'scale-100 opacity-10'}`}></div>
        <svg viewBox="0 0 100 140" className="w-full h-full drop-shadow-[0_0_40px_rgba(251,191,36,0.3)] transition-transform duration-1000">
            <defs>
                <linearGradient id="astralBody" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="rgba(15, 23, 42, 0.95)" />
                    <stop offset="100%" stopColor="rgba(15, 23, 42, 0.95)" />
                </linearGradient>
                <filter id="activeGlow"><feGaussianBlur stdDeviation="2" result="blur"/><feComposite in="SourceGraphic" in2="blur" operator="over"/></filter>
            </defs>
            <path d="M47 25 L53 25 L52 35 L48 35 Z" fill="url(#astralBody)" stroke="#475569" strokeWidth="0.5" />
            <path d="M30 35 L70 35 L78 55 L70 55 L65 40 L35 40 L30 55 L22 55 Z" 
                fill={activeMuscles.includes('shoulders') ? "#f59e0b" : "url(#astralBody)"} 
                filter={activeMuscles.includes('shoulders') ? "url(#activeGlow)" : ""}
                strokeWidth="0.5" stroke="#475569"
            />
            <g style={{ transform: isContracting ? 'scaleY(0.92) translateY(2px)' : 'none', transformOrigin: '50% 70%', transition: 'transform 0.9s' }}>
                <path d="M40 40 L60 40 L65 75 L35 75 Z" 
                    fill={activeMuscles.includes('core') ? "#fbbf24" : "url(#astralBody)"} 
                    className={isBreathing ? "animate-breathe" : ""}
                    filter={activeMuscles.includes('core') ? "url(#activeGlow)" : ""}
                    strokeWidth="0.5" stroke="#475569"
                />
            </g>
            <circle cx="50" cy="18" r="10" fill="url(#astralBody)" stroke="#fbbf24" strokeWidth="1" />
        </svg>
    </div>
));

// --- Komponent: WatchView (Tryb Zegarka) ---
const WatchView = ({ chakra, isAlert, onClose, onVoice }: any) => (
  <div className="fixed inset-0 z-[400] bg-black/95 flex items-center justify-center animate-in fade-in zoom-in duration-300 backdrop-blur-md">
    <div className={`relative w-80 h-80 rounded-full border-4 ${isAlert ? 'border-red-600 animate-pulse shadow-[0_0_60px_rgba(220,38,38,0.5)]' : 'border-white/10'} flex flex-col items-center justify-center glass overflow-hidden`}>
      <div className={`absolute inset-0 bg-gradient-to-br ${chakra.color} opacity-20 blur-3xl`}></div>
      
      <div className="z-10 flex flex-col items-center space-y-4">
        <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${chakra.color} flex items-center justify-center border-2 border-white/20 shadow-2xl animate-levitate`}>
           <span className="text-3xl font-black text-white drop-shadow-md">{chakra.mantra}</span>
        </div>
        
        <div className="text-center px-6">
          <h4 className={`text-[10px] font-black uppercase tracking-[0.3em] ${isAlert ? 'text-red-400' : 'text-sky-300'}`}>
            {isAlert ? 'Alert Immunologiczny' : 'Tryb Zegarka'}
          </h4>
          <p className="text-[14px] text-white/90 font-serif italic mt-1">{chakra.name}</p>
        </div>

        <div className="flex gap-4">
            <button onClick={onVoice} className="p-4 bg-sky-900/40 rounded-full border border-sky-400/30 active:scale-90 transition-all hover:bg-sky-800/60 shadow-lg" title="Przewodnik Głosowy">
              <svg className="w-6 h-6 text-sky-200" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
            </button>
            <button onClick={onClose} className="px-6 py-4 bg-red-950/40 rounded-full border border-red-500/30 text-[10px] font-black uppercase tracking-widest text-red-200 active:scale-90 transition-all hover:bg-red-900/60 shadow-lg">
                Wyjdź
            </button>
        </div>
      </div>
      
      {/* Dekoracyjne elementy zegarka */}
      <div className="absolute inset-0 pointer-events-none">
          {[...Array(12)].map((_, i) => (
              <div key={i} className="absolute inset-0 flex items-start justify-center" style={{ transform: `rotate(${i * 30}deg)` }}>
                  <div className="w-[2px] h-3 bg-white/10 mt-2"></div>
              </div>
          ))}
      </div>
    </div>
  </div>
);

// --- Główny Komponent App ---
export default function App() {
  const [view, setView] = useState<'home' | AppTab>('home');
  const [isScattered, setIsScattered] = useState(false);
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('stoic_progress_v42');
    return saved ? JSON.parse(saved) : { points: 0, level: 1, completedTasks: [] };
  });
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('stoic_notes_v42');
    return saved ? JSON.parse(saved) : [];
  });
  const [isWatchActive, setIsWatchActive] = useState(false);
  const [isImmuneLow, setIsImmuneLow] = useState(false);
  const [activeYogaExercise, setActiveYogaExercise] = useState<YogaExercise | null>(null);

  useEffect(() => { localStorage.setItem('stoic_progress_v42', JSON.stringify(progress)); }, [progress]);
  useEffect(() => { localStorage.setItem('stoic_notes_v42', JSON.stringify(notes)); }, [notes]);

  // Monitor odporności
  useEffect(() => {
    const sicknessKeywords = ['chory', 'przeziębienie', 'słabo', 'ból', 'gardło', 'gorączka', 'katar', 'zmęczenie'];
    const hasSickness = notes.some(n => sicknessKeywords.some(k => n.content.toLowerCase().includes(k)));
    setIsImmuneLow(hasSickness);
  }, [notes]);

  const addPoints = (amount: number) => {
    setProgress(prev => {
        const newPoints = prev.points + amount;
        let newLevel = prev.level;
        const nextStep = PROGRESS_STEPS.find(s => s.level === prev.level + 1);
        if (nextStep && newPoints >= nextStep.threshold) newLevel = nextStep.level;
        return { ...prev, points: newPoints, level: newLevel };
    });
  };

  const playTTS = async (text: string) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Jako Gwiezdny Mnich powiedz kojącym głosem: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
        },
      });
      const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (audioData) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
        const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start();
      }
    } catch (e) { console.error("TTS Error", e); }
  };

  const menuIcons = useMemo(() => [
    { label: "Zegarek", tab: AppTab.WATCH_MODE, color: "bg-black border-white/20", angle: -170, petals: 2, icon: <span className="text-xl">⌚</span>, desc: "Szybki monitoring i odporność" },
    { label: "Wiedza AI", tab: AppTab.KNOWLEDGE_BASE, color: "bg-gradient-to-br from-indigo-600 to-blue-400", angle: -130, petals: 100, icon: <span className="text-3xl font-greek">Σ</span>, desc: "Baza Twojego rozwoju i zdrowia" },
    { label: "Stoicyzm", tab: AppTab.STOIC, color: "bg-gradient-to-br from-red-600 to-red-950", angle: -90, petals: 4, icon: <span className="text-3xl font-greek">Φ</span>, desc: "Lekcje spokoju na każdy dzień" },
    { label: "Joga", tab: AppTab.YOGA, color: "bg-gradient-to-br from-amber-400 via-white to-amber-200", angle: -50, petals: 32, icon: <span className="text-3xl font-serif text-amber-900">ॐ</span>, desc: "Dyscyplina ciała i oddechu" },
    { label: "Medytacja", tab: AppTab.MEDITATE, color: "bg-gradient-to-br from-green-500 to-green-950", angle: -10, petals: 12, icon: <span className="text-3xl font-greek">Ψ</span>, desc: "Podróż w głąb ciszy" },
    { label: "Zapiski", tab: AppTab.JOURNAL, color: "bg-gradient-to-br from-blue-400 to-blue-900", angle: 30, petals: 16, icon: <span className="text-3xl font-greek">Λ</span>, desc: "Twój osobisty dziennik mocy" },
    { label: "Dialog", tab: AppTab.CHAT, color: "bg-gradient-to-br from-purple-600 to-purple-950", angle: 70, petals: 24, icon: <span className="text-3xl font-greek">Ξ</span>, desc: "Rozmowa z Gwiezdnym Mędrcem" },
    { label: "Mantry", tab: AppTab.AFFIRMATIONS, color: "bg-gradient-to-br from-orange-500 to-orange-900", angle: 110, petals: 6, icon: <span className="text-3xl font-greek">Δ</span>, desc: "Wibracje transformujące umysł" },
    { label: "Czakry", tab: AppTab.CHAKRAS, color: "bg-gradient-to-br from-yellow-400 to-yellow-800", angle: 150, petals: 10, icon: <span className="text-3xl font-greek">Ω</span>, desc: "Harmonizacja centrów energetycznych" },
  ], []);

  // Dekoracyjne 7 czakr pomiędzy ikonami - Symetryczny rozkład na ring wewnętrzny
  const decorativeChakras = useMemo(() => CHAKRAS.map((c, i) => ({
      ...c,
      angle: (i * (360 / 7)) - 90 // Start od góry, symetryczny podział co ~51.4 stopnia
  })), []);

  const currentStep = PROGRESS_STEPS.find(s => s.level === progress.level) || PROGRESS_STEPS[0];

  return (
    <div className="max-w-md mx-auto h-screen flex flex-col relative overflow-hidden bg-transparent">
      {/* Tryb Zegarka - Overlay */}
      {isWatchActive && (
        <WatchView 
          chakra={isImmuneLow ? CHAKRAS[4] : CHAKRAS[2]} 
          isAlert={isImmuneLow}
          onClose={() => setIsWatchActive(false)}
          onVoice={() => playTTS(isImmuneLow ? "Twój system obronny jest osłabiony. Pracuj nad czakrą gardła, nucąc mantrę HAM. To Twoja tarcza immunologiczna." : "Twoja energia płynie harmonijnie. Podtrzymuj ten stan uważnością.")}
        />
      )}

      {view === 'home' ? (
        <div className="flex-1 flex flex-col items-center justify-center p-4 z-10 overflow-hidden">
          <header className="absolute top-8 text-center w-full px-4 animate-in fade-in duration-1000">
            <h1 className="text-3xl font-serif text-amber-50 tracking-[0.2em] uppercase drop-shadow-[0_0_15px_rgba(249,115,22,0.6)]">Gwiezdny Mnich</h1>
            <div className="mt-4 flex flex-col items-center gap-1">
                <span className={`text-[9px] font-black uppercase tracking-widest bg-gradient-to-r ${currentStep.color} bg-clip-text text-transparent px-3 py-1 border border-white/5 rounded-full`}>{currentStep.title}</span>
            </div>
          </header>
          
          <div className="relative flex items-center justify-center w-full h-[540px] mt-12">
            {/* Tło astronomiczne */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-[300px] h-[300px] border border-white/5 rounded-full animate-spin-very-slow"></div>
              <div className="absolute w-[360px] h-[360px] border border-dashed border-sky-500/10 rounded-full animate-spin-reverse-slow"></div>
            </div>

            {/* Postać centralna */}
            <div className="relative z-20 cursor-pointer animate-levitate transition-transform hover:scale-110 active:scale-95" onClick={() => setIsScattered(!isScattered)}>
               <svg width="100" height="120" viewBox="0 0 100 120" fill="none">
                  <path d="M50 15C42 15 36 21 36 29C36 37 42 42 50 42C58 42 64 37 64 29C64 21 58 15 50 15Z" stroke="#fbbf24" strokeWidth="1.5"/>
                  <path d="M36 34C30 40 25 50 25 65C25 80 35 100 50 100C65 100 75 80 75 65C75 50 70 40 64 34" stroke="#fbbf24" strokeWidth="2"/>
               </svg>
            </div>

            {/* Dekoracyjne 7 czakr z krążącymi płomykami (Ring Wewnętrzny) */}
            {decorativeChakras.map((chakra, i) => {
                const radius = isScattered ? 170 : 90;
                const x = Math.cos(chakra.angle * (Math.PI / 180)) * radius;
                const y = Math.sin(chakra.angle * (Math.PI / 180)) * radius;
                return (
                    <div key={`decor-${i}`} className="absolute z-10 pointer-events-none transition-all duration-1000 ease-[cubic-bezier(0.19,1,0.22,1)]"
                         style={{ transform: `translate(${x}px, ${y}px)` }}>
                        {/* Aura Czakry */}
                        <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${chakra.color} opacity-20 blur-[1px] border border-white/10 flex items-center justify-center shadow-lg`}>
                            <span className="text-white/40 text-[7px] font-black drop-shadow-md">{chakra.mantra}</span>
                        </div>
                        
                        {/* Krążący Płomyk (Flame) */}
                        <div className="absolute inset-0 animate-spin-fast" style={{ animationDuration: '4s', animationDelay: `${i * 0.5}s` }}>
                            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-2 h-3 bg-gradient-to-b from-orange-300 via-orange-500 to-red-600 rounded-full blur-[2px] shadow-[0_0_10px_rgba(249,115,22,0.8)] opacity-90 animate-flame-flicker"></div>
                        </div>
                    </div>
                );
            })}

            {/* Wirujące ikony z opisami na hover */}
            {menuIcons.map((item, i) => {
              const radius = isScattered ? 215 + (i * 2) : 140;
              const x = Math.cos(item.angle * (Math.PI / 180)) * radius;
              const y = Math.sin(item.angle * (Math.PI / 180)) * radius;
              return (
                <div key={i} className="absolute z-50 flex flex-col items-center transition-all duration-700 ease-[cubic-bezier(0.19,1,0.22,1)]"
                     style={{ transform: `translate(${x}px, ${y}px)` }}>
                  <div className="group relative flex flex-col items-center animate-float-slow" style={{ animationDelay: `${i * 0.15}s` }}>
                    
                    {/* Tooltip / Opis na hover */}
                    <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none transform translate-y-2 group-hover:translate-y-0 z-[100]">
                        <div className="bg-slate-900/90 backdrop-blur-md border border-white/20 px-4 py-2 rounded-2xl shadow-2xl whitespace-nowrap">
                            <p className="text-[10px] text-white font-serif italic text-center">{item.desc}</p>
                        </div>
                    </div>

                    <button 
                      onClick={() => item.tab === AppTab.WATCH_MODE ? setIsWatchActive(true) : setView(item.tab)}
                      className={`w-15 h-15 sm:w-18 sm:h-18 rounded-full flex items-center justify-center shadow-2xl border-2 border-white/20 relative overflow-hidden transition-all group-hover:scale-125 active:scale-95 ${item.color}`}
                    >
                      <ChakraGeometry petals={item.petals} />
                      <div className="relative z-10 font-greek text-white drop-shadow-md">{item.icon}</div>
                    </button>

                    <div className={`mt-3 px-3 py-1 glass rounded-full border border-white/10 text-[7px] font-black uppercase tracking-widest text-white transition-opacity duration-500 ${isScattered ? 'opacity-100' : 'opacity-0'}`}>
                      {item.label}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="absolute bottom-10 flex flex-col items-center gap-4">
             <button onClick={() => playTTS("Głos Gwiezdnego Mnicha jest z Tobą. Słuchaj swojej wewnętrznej mądrości.")} 
                     className="px-8 py-3 glass rounded-full text-[9px] font-black uppercase tracking-widest text-sky-200 border border-sky-500/30 active:scale-95 transition-all shadow-[0_0_20px_rgba(56,189,248,0.2)]">
                Przewodnik Głosowy
             </button>
             {isImmuneLow && (
                 <div className="flex items-center gap-2 animate-pulse">
                     <div className="w-2 h-2 rounded-full bg-red-500"></div>
                     <span className="text-[8px] font-black text-red-400 uppercase tracking-widest">Alert Zdrowia: Sprawdź Zegarek</span>
                 </div>
             )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col z-[100] h-full overflow-hidden bg-slate-950/98 backdrop-blur-3xl animate-in fade-in duration-500">
            <header className="p-5 pt-14 pb-5 glass border-b border-white/10 flex items-center justify-between">
                <button onClick={() => setView('home')} className="p-3 bg-sky-900/40 rounded-xl border border-sky-400/20 active:scale-90 transition-all hover:bg-sky-800/60">
                    <svg className="h-5 w-5 text-sky-300" viewBox="0 0 20 20" fill="currentColor"><path d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" /></svg>
                </button>
                <h2 className="text-[10px] font-serif text-sky-100 tracking-[0.2em] uppercase">{view}</h2>
                <div className="flex items-center gap-2">
                    <span className="text-[9px] font-black text-orange-400">{progress.points} pkt</span>
                </div>
            </header>

            <main className="flex-1 overflow-y-auto p-5 pb-32 no-scrollbar">
                {view === AppTab.YOGA && (
                   <div className="space-y-10 py-6 animate-in slide-in-from-bottom duration-700">
                      <div className="glass p-8 rounded-[3rem] border border-amber-500/20 flex flex-col items-center relative overflow-hidden">
                         <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 to-transparent opacity-30"></div>
                         <YogaBot activeMuscles={activeYogaExercise?.muscles || []} isBreathing={!!activeYogaExercise} />
                         <p className="mt-4 text-xs font-serif italic text-amber-200/80">{activeYogaExercise?.name || "Oczekuję na wybór praktyki"}</p>
                      </div>
                      <div className="space-y-4">
                        <h3 className="text-[10px] font-black text-amber-500 uppercase tracking-widest pl-2">Sesje Aktywacji</h3>
                        {YOGA_PRACTICES.map((ex, i) => (
                           <div key={i} className={`glass p-6 rounded-3xl border transition-all ${activeYogaExercise?.name === ex.name ? 'border-amber-400 bg-amber-500/10 shadow-lg' : 'border-white/5'} space-y-3`}>
                              <div className="flex justify-between items-center">
                                  <h4 className="text-white font-serif italic">{ex.name}</h4>
                                  <span className="text-[8px] text-amber-400 font-black">{ex.duration}</span>
                              </div>
                              <p className="text-[11px] text-slate-400 leading-relaxed italic">{ex.desc}</p>
                              <button onClick={() => { setActiveYogaExercise(ex); addPoints(20); }} className="w-full py-3 bg-amber-900/30 border border-amber-500/30 rounded-xl text-[9px] font-black text-amber-100 uppercase tracking-widest active:scale-95 transition-all">Ćwicz +20 pkt</button>
                           </div>
                        ))}
                      </div>
                   </div>
                )}
                
                {/* Fallback dla innych sekcji */}
                {view !== AppTab.YOGA && (
                    <div className="flex flex-col items-center justify-center py-24 space-y-6">
                        <div className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center animate-pulse">
                            <div className="w-2 h-2 rounded-full bg-sky-500"></div>
                        </div>
                        <div className="text-center italic text-white/40 text-sm font-serif">
                            Sekcja {view} czeka na Twoją obecność.<br/>Zacznij oddech, poczuj przestrzeń.
                        </div>
                    </div>
                )}
            </main>
        </div>
      )}

      <style>{`
        @keyframes brough-slow { 0%, 100% { transform: scale(1); opacity: 0.8; } 50% { transform: scale(1.06); opacity: 1; } }
        .animate-breathe { animation: brough-slow 4.5s infinite ease-in-out; }
        @keyframes levitate { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-12px); } }
        .animate-levitate { animation: levitate 6s infinite ease-in-out; }
        @keyframes rotateCW { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes rotateCCW { from { transform: rotate(360deg); } to { transform: rotate(0deg); } }
        .animate-spin-very-slow { animation: rotateCW 140s linear infinite; }
        .animate-spin-reverse-slow { animation: rotateCCW 100s linear infinite; }
        .animate-spin-slow { animation: rotateCW 18s linear infinite; }
        .animate-spin-fast { animation: rotateCW 3s linear infinite; }
        @keyframes float-slow { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
        .animate-float-slow { animation: float-slow 4.5s infinite ease-in-out; }
        @keyframes flame-flicker {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.8; }
            50% { transform: translate(-50%, -60%) scale(1.1); opacity: 1; }
        }
        .animate-flame-flicker { animation: flame-flicker 0.4s infinite alternate ease-in-out; }
      `}</style>
    </div>
  );
}
