
import { ChakraInfo, Mantra, StoicQuote } from './types';

export const PROGRESS_STEPS = [
  { level: 1, title: "Cień Pustki", threshold: 0, description: "Dopiero zaczynasz dostrzegać iskry w ciemności.", color: "from-slate-700 to-slate-900" },
  { level: 2, title: "Nowicjusz Ognia", threshold: 50, description: "Zapłonęła w Tobie chęć poznania siebie.", color: "from-orange-700 to-red-900" },
  { level: 3, title: "Adept Lodu", threshold: 150, description: "Twoje emocje zaczynają przypominać spokojną taflę jeziora.", color: "from-sky-600 to-blue-900" },
  { level: 4, title: "Strażnik Równowagi", threshold: 400, description: "Ogień pasji i lód spokoju tańczą w Twoim sercu.", color: "from-orange-500 to-sky-600" },
  { level: 5, title: "Gwiezdny Mnich", threshold: 1000, description: "Osiągnąłeś harmonię, o której inni tylko śnią.", color: "from-amber-400 via-white to-sky-400" }
];

export const CONTACT_INFO = {
  label: "Lekcje Indywidualne",
  phone: "+48 508 972 649",
  description: "Zrozumienie, spokój i zmiana pod okiem przewodnika."
};

export const YOGA_SUBSCRIPTION = {
  status: "Premium",
  lastUpdate: "Marzec 2024",
  nextUpdate: "Kwiecień 2024",
  price: "Dostęp Miesięczny: 29 PLN"
};

export interface YogaExercise {
  name: string;
  desc: string;
  duration: string;
  muscles: string[]; // Grupy mięśni: 'neck', 'shoulders', 'core', 'hips', 'legs', 'back'
}

export const YOGA_PRACTICES: YogaExercise[] = [
  { 
    name: "Pierwsza Viloma", 
    desc: "Oddech schodkowy - wdech dzielony na 3 etapy z krótkimi zatrzymaniami. Buduje pojemność płuc.", 
    duration: "5 min", 
    muscles: ['core', 'shoulders'] 
  },
  { 
    name: "Druga Viloma", 
    desc: "Kontrolowany, schodkowy wydech. Uczy panowania nad układem nerwowym i wycisza umysł.", 
    duration: "5 min", 
    muscles: ['core', 'back'] 
  },
  { 
    name: "Dirgha na leżąco", 
    desc: "Pełny oddech jogiczny w pozycji leżącej. Wypełnianie brzucha, klatki i szczytów płuc.", 
    duration: "10 min", 
    muscles: ['core', 'back', 'neck'] 
  },
  {
    name: "Skośna Aktywacja Żeber",
    desc: "Leżąc płasko na plecach, napnij mocno mięśnie głębokie brzucha. Delikatnie unieś klatkę piersiową, kierując mostek w stronę przeciwległego biodra. Skup się na wewnętrznych partiach mięśni międzyżebrowych, czując jak napięcie wędruje po skosie przez tułów.",
    duration: "6 min",
    muscles: ['core', 'shoulders', 'back']
  },
  {
    name: "Spiralny Splot do Brzucha",
    desc: "Zegnij nogi w kolanach i przyciągnij je powoli do brzucha. Trzymając mocno napięty dół brzucha, wykonuj mikro-ruchy klatką piersiową w stronę kolan. Oddychaj płytko i precyzyjnie, celując powietrzem w okolice żeber po przeciwnej stronie niż skręt miednicy.",
    duration: "8 min",
    muscles: ['core', 'hips', 'back']
  }
];

export const APP_INTRODUCTION = {
  title: "Brama do Wnętrza",
  content: "Życie to olimpiada, która już się zaczęła. Każda dyscyplina potrzebuje praktyki. Dbając o ciało, ducha i umysł (Twój Święty Trójkąt), będziesz mógł dłużej cieszyć się czasem.\n\n• Ciało: Gimnastyka i jedzenie.\n• Umysł: Czytanie i stoicyzm.\n• Dusza: Medytacja i pobycie ze sobą.\n\nJesteś najwyższą wartością wtedy, gdy nikt nie patrzy. Nie ulegaj normom, które narzuca świat. Żyj w harmonii ze sobą.",
  footer: "Zacznij swój trening już teraz."
};

export const CATEGORIZED_AFFIRMATIONS = {
  "Bezpieczeństwo i Spokój": [
    "Jestem bezpieczny, wszystko będzie dobrze.",
    "Czuję, jak z każdym oddechem odprężam się coraz bardziej.",
    "Jestem wystarczająco silny, by przez to przejść.",
    "Wiem, że idealne rozwiązanie nadejdzie.",
    "Mam kontrolę nad tym, jak się czuję – wybieram spokój.",
    "To również minie (Memento Stoic).",
    "Odpuszczam rzeczy, na które nie mam wpływu.",
    "Oddaję moje zmartwienia wszechświatowi.",
    "Gdy odliczam 1..2..3, zmartwienia mnie opuszczają."
  ],
  "Miłość i Akceptacja": [
    "Akceptuję siebie takim, jakim jestem. Bycie sobą daje mi bezpieczeństwo.",
    "Jestem idealny taki, jaki jestem. Kocham siebie.",
    "Codziennie czuję się ze sobą dobrze.",
    "Mogę zrobić wszystko, o czym pomyślę.",
    "Otacza mnie miłość i światło.",
    "Ufam sobie i decyzjom, które podejmuję.",
    "Jestem dokładnie tu, gdzie powinienem być.",
    "Uwalniam się od przeszłości i wybaczam sobie."
  ],
  "Zdrowie i Witalność": [
    "Jestem zdrowy i promieniuję zdrowiem ciała, umysłu i ducha.",
    "Z każdym wydechem wydalam z ciała wszelkie słabości.",
    "Moje ciało posiada boską mądrość do samoleczenia.",
    "Każdego dnia staję się silniejszy w nowy sposób.",
    "Gdy się uzdrawiam, staję się źródłem uzdrowienia dla innych.",
    "Słucham mojego ciała i odpowiadam na jego potrzeby.",
    "Dotleniam ciało świeżym powietrzem, śmiechem i aktywnością."
  ],
  "Obfitość i Finanse": [
    "Pieniądze nieustannie napływają do mojego życia.",
    "Wyczuwam obfitość we wszystkich obszarach życia.",
    "Dziękuję za wszystko, co mam.",
    "Każda złotówka, którą wydaję, powraca do mnie w cudowny sposób.",
    "Zasługuję na bogactwo i pomyślność.",
    "Z łatwością mogę zarobić więcej pieniędzy.",
    "Moja wartość nie zależy od mojej sytuacji finansowej."
  ]
};

export const CHAKRAS: ChakraInfo[] = [
  {
    name: "Czakra Podstawy",
    sanskrit: "Muladhara",
    color: "from-red-600 to-red-900 shadow-red-500/40",
    location: "Podstawa kręgosłupa, kość ogonowa",
    mantra: "LAM",
    description: "Ugruntowanie i przetrwanie. Twoje korzenie."
  },
  {
    name: "Czakra Sakralna",
    sanskrit: "Svadhisthana",
    color: "from-orange-500 to-orange-800 shadow-orange-500/40",
    location: "Podbrzusze, 3 cm poniżej pępka",
    mantra: "VAM",
    description: "Kreatywność, pasja i radość życia."
  },
  {
    name: "Czakra Splotu Słonecznego",
    sanskrit: "Manipura",
    color: "from-yellow-400 to-yellow-700 shadow-yellow-400/40",
    location: "Okolice pępka, splot słoneczny",
    mantra: "RAM",
    description: "Siła woli, pewność siebie i moc działania."
  },
  {
    name: "Czakra Serca",
    sanskrit: "Anahata",
    color: "from-green-500 to-green-800 shadow-green-500/40",
    location: "Centrum klatki piersiowej",
    mantra: "YAM",
    description: "Miłość, współczucie i harmonia."
  },
  {
    name: "Czakra Gardła",
    sanskrit: "Vishuddha",
    color: "from-blue-400 to-blue-700 shadow-blue-400/40",
    location: "Gardło, krtań",
    mantra: "HAM",
    description: "Prawda, ekspresja i komunikacja."
  },
  {
    name: "Czakra Trzeciego Oka",
    sanskrit: "Ajna",
    color: "from-indigo-600 to-indigo-950 shadow-indigo-600/40",
    location: "Między brwiami",
    mantra: "OM",
    description: "Intuicja i wewnętrzna mądrość."
  },
  {
    name: "Czakra Korony",
    sanskrit: "Sahasrara",
    color: "from-white via-slate-100 to-slate-200 shadow-white/70",
    location: "Czubek głowy",
    mantra: "AH",
    description: "Jedność z wszechświem i oświecenie."
  }
];

export const CHAKRA_PRACTICES = {
  "Czakra Podstawy": {
    exercise: "5 przysiadów, ugruntowanie.",
    affirmations: ["Jestem bezpieczny/a i mam wszystko, czego potrzebuję."],
    visualization: "Czerwona kula światła."
  },
  "Czakra Sakralna": {
    exercise: "Krążenia biodrami.",
    affirmations: ["Akceptuję swoje emocje i cieszę się każdą chwilą."],
    visualization: "Pomarańczowa kula światła."
  },
  "Czakra Splotu Słonecznego": {
    exercise: "Oddech brzuszny.",
    affirmations: ["Mam moc kreowania własnego życia."],
    visualization: "Złota kula światła."
  },
  "Czakra Serca": {
    exercise: "Otwieranie ramion.",
    affirmations: ["Kocham, jestem kochany/a i wybaczam sobie oraz innym."],
    visualization: "Zielona kula światła."
  },
  "Czakra Gardła": {
    exercise: "Nucenie HAM.",
    affirmations: ["Moje słowa niosą prawdę i dobro."],
    visualization: "Błękitna kula światła."
  },
  "Czakra Trzeciego Oka": {
    exercise: "Masaż czoła.",
    affirmations: ["Ufam swojej intuicji i widzę jasno."],
    visualization: "Indygo kula światła."
  },
  "Czakra Korony": {
    exercise: "Zatocz 3 kręgi dłońmi nad głową.",
    affirmations: ["Jestem jednością ze wszystkim, co istnieje."],
    visualization: "Biała kula światła."
  }
};

export const MORNING_RITUAL = [
  "Szklanka wody - przebudzenie organizmu",
  "5 przysiadów - aktywacja energii",
  "Kręcenie biodrami - rozluźnienie miednicy",
  "Ćwiczenia ramion - otwarcie klatki",
  "Masaż głowy i oczu - jasność umysłu",
  "Zimna woda na twarz - świeżość",
  "5 minut medytacji w ciszy - spokój ducha"
];

export const EVENING_RITUAL = [
  "Usiądź wygodnie w pozycji lotosu w ciszy",
  "Masaż pod pępkiem (żółta kula światła)",
  "Masaż nad pępkiem (pomarańczowa kula - ucisk i puszczenie przy wydechu)",
  "Ręka na sercu, druga z tyłu (zielona kula miłości)",
  "Wizualizacja gardła (jasnoniebieska kula prawdy)",
  "Wizualizacja przy buzi (granatowa kula + trzecie oko)",
  "Zatocz 3 kręgi dłońmi nad głową (fiolet/biel)",
  "2 minuty wyciszenia - Jestem Tu i Teraz",
  "Ćwiczenia na pośladki i nogi (wedle uznania)",
  "Afirmacja: Jestem spokojem, noc przynosi regenerację"
];

export const MANTRAS: Mantra[] = [
  { text: "Pieniądze nieustannie napływają do mojego życia", translation: "Obfitość", purpose: "MATERIA" },
  { text: "Jestem wystarczająco silny by przez to przejść", translation: "Siła", purpose: "UMYSŁ" },
  { text: "Dziś będzie cudowny dzień błogosławieństw", translation: "Nadzieja", purpose: "DUCH" },
  { text: "Wiem, że jestem chroniony", translation: "Ochrona", purpose: "CIAŁO" }
];

export const STOIC_QUOTES: StoicQuote[] = [
  { text: "Nie zdarzenia nas niepokoją, ale nasze o nich sądy.", author: "Epiktet" },
  { text: "Można stać spokojnie i przyglądać się, wypchnięcie uczuć pomaga zrzucić kamienie z pleców.", author: "Marek Aureliusz" },
  { text: "Rób swój i nie zważaj na innych, Twoja prawda jest w Tobie.", author: "Notatki Stoika" }
];

export const JOURNAL_PROMPTS = [
  "Co dzisiaj zrozumiałem/am o sobie?",
  "Za co odczuwam dziś najgłębszą wdzięczność?",
  "Jaki bodziec dziś mnie poruszył i jak zareagowałem/am?"
];
